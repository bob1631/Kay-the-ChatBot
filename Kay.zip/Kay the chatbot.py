import time
import sys
#prints things
print("Hi! I'm Kay! Ask me whatever you would like ")
print("DISCLAIMER: Kay is a small project made by reese ivey")
#code of the chatbot
while True:
    user_input = input("Human: ")

    if user_input == "hello" or user_input == "hi":
        print("Hello! Nice to meet you")
    elif user_input == "what's your name":
        print("Kay")
    elif user_input == "bye":
        print("Goodbye!")
        time.sleep(2)
        sys.exit()
    elif user_input == "":
        print("Ask me anything please")
    else:
        print("huh")

