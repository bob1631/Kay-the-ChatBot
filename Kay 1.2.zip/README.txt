make sure you have python installed.

you can change the source code and the file called kay.txt contains the original code for the chatbot.


to run the application just click on the file with the .py extenstion

type bye or goodbye to close the application or press the X button.
VERSION 1.2