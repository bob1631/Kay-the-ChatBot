import time
import sys

#prints things
print("Hi! I'm Kay! Ask me whatever you would like")
print("DISCLAIMER: Kay is a small project made by me VERSION 1.2")

#code of the chatbot
while True:
    user_input = input("Human: ")

    if user_input == "hello" or user_input == "hi":
        print("Kay: Hello! Nice to meet you")
    elif user_input == "what's your name":
        print("Kay: My name is Kay")
    elif user_input == "bye" or user_input == "goodbye":
        print("Kay: Goodbye!")
        time.sleep(2)
        sys.exit()
    elif user_input == "":
        print("Kay: Ask me anything, please")
    elif user_input == "what were you programmed in" or user_input == "what were you programmed in?":
        print("Kay: I was made in Python")
    elif user_input == "what were you coded in" or user_input == "what were you coded in?":
        print("Kay: I was made in Python")
    elif user_input == "hello!":
        print("Kay: Hello! Nice to meet you")
    elif user_input == "hi!":
        print("Kay: Hello! Nice to meet you")
    else:
        print("Kay: I dont understand, can you please reprhase that if you could?")
